-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.0.51b-community-nt - MySQL Community Edition (GPL)
-- Server OS:                    Win32
-- HeidiSQL version:             7.0.0.4053
-- Date/time:                    2002-01-30 00:34:33
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;

-- Dumping database structure for online_test
CREATE DATABASE IF NOT EXISTS `online_test` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `online_test`;


-- Dumping structure for table online_test.question
CREATE TABLE IF NOT EXISTS `question` (
  `Question_id` int(10) NOT NULL auto_increment,
  `Subject` varchar(50) default NULL,
  `question` varchar(500) default NULL,
  `optionA` varchar(50) default NULL,
  `optionB` varchar(50) default NULL,
  `optionC` varchar(50) default NULL,
  `optionD` varchar(50) default NULL,
  `Answer` varchar(100) default NULL,
  `selectans` varchar(100) default 'NA',
  PRIMARY KEY  (`Question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- Dumping data for table online_test.question: ~6 rows (approximately)
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` (`Question_id`, `Subject`, `question`, `optionA`, `optionB`, `optionC`, `optionD`, `Answer`, `selectans`) VALUES
	(1, 'C', 'Who Invented C language?', 'Abhishek', 'Aman', 'Alok', 'Rahul', 'None of these', 'NA'),
	(2, 'C', 'What is the SiZe if int data type in C?', '4 byte', '2 byte', '1 byte', '3 byte', '2 byte', 'NA'),
	(3, 'Database', 'What is the use of group command?', 'sds', 'sdfg', 'dg', 'dgdg', 'gdg', 'NA'),
	(4, 'C', 'What is Pointer ?', 'Use for referencr', 'Data type', 'Hold the address of another variablr', 'None of these', 'Hold the address of another variablr', 'NA'),
	(5, 'Database', 'A null value is assigned when no other value applied', 'True', 'False', 'Some Time', '0', 'True', 'NA'),
	(6, 'Database', 'ORDER BY can be combine with SELECT statement', 'True', 'False', 'By using WhereClause', 'None ofthese', NULL, 'NA');
/*!40000 ALTER TABLE `question` ENABLE KEYS */;


-- Dumping structure for table online_test.subject
CREATE TABLE IF NOT EXISTS `subject` (
  `id` int(10) NOT NULL auto_increment,
  `subject` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table online_test.subject: ~4 rows (approximately)
/*!40000 ALTER TABLE `subject` DISABLE KEYS */;
INSERT INTO `subject` (`id`, `subject`) VALUES
	(1, 'C'),
	(2, 'Database'),
	(3, 'Java'),
	(5, 'Math');
/*!40000 ALTER TABLE `subject` ENABLE KEYS */;


-- Dumping structure for table online_test.user
CREATE TABLE IF NOT EXISTS `user` (
  `Name` varchar(50) default NULL,
  `Password` varchar(50) default NULL,
  `Email` varchar(50) NOT NULL default '',
  `Contact` varchar(11) default NULL,
  `User_type` varchar(50) default NULL,
  PRIMARY KEY  (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table online_test.user: ~5 rows (approximately)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`Name`, `Password`, `Email`, `Contact`, `User_type`) VALUES
	('abhi', '123', 'abhi@gmail.com', '3424', 'Admin'),
	('aman', '123', 'aman@gmail.com', '32535', 'User'),
	('ashu', '123', 'ashu@gmail.com', '346536', 'User'),
	('kd', '123', 'kd@gmail.com', '12', 'User'),
	('user', '123', 'user@gmail.com', '3456', 'User');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
/*!40014 SET FOREIGN_KEY_CHECKS=1 */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
