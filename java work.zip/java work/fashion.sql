-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.0.51b-community-nt - MySQL Community Edition (GPL)
-- Server OS:                    Win32
-- HeidiSQL version:             7.0.0.4053
-- Date/time:                    2016-11-20 22:23:25
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;

-- Dumping database structure for fashion
CREATE DATABASE IF NOT EXISTS `fashion` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `fashion`;


-- Dumping structure for table fashion.category
CREATE TABLE IF NOT EXISTS `category` (
  `category_id` int(10) NOT NULL auto_increment,
  `category_name` varchar(100) default NULL,
  PRIMARY KEY  (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table fashion.category: ~5 rows (approximately)
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`category_id`, `category_name`) VALUES
	(1, 'Shirts & Tops'),
	(2, 'Kurtas & Kurtis'),
	(3, 'Leggings & Jeggings'),
	(4, 'Trousers'),
	(5, 'Footwear');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;


-- Dumping structure for table fashion.kart
CREATE TABLE IF NOT EXISTS `kart` (
  `productid` int(10) default NULL,
  `username` varchar(100) default NULL,
  `email` varchar(100) default NULL,
  `productname` varchar(100) default NULL,
  `price` float default NULL,
  `image` varchar(50) default NULL,
  `quantity` int(10) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table fashion.kart: ~0 rows (approximately)
/*!40000 ALTER TABLE `kart` DISABLE KEYS */;
/*!40000 ALTER TABLE `kart` ENABLE KEYS */;


-- Dumping structure for table fashion.product
CREATE TABLE IF NOT EXISTS `product` (
  `id` int(10) NOT NULL auto_increment,
  `category` varchar(100) default NULL,
  `name` varchar(100) default NULL,
  `size` varchar(50) default NULL,
  `price` double default NULL,
  `description` varchar(100) default NULL,
  `image` varchar(100) default NULL,
  `quantity` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

-- Dumping data for table fashion.product: ~20 rows (approximately)
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` (`id`, `category`, `name`, `size`, `price`, `description`, `image`, `quantity`) VALUES
	(1, 'Kurtas & Kurtis', 'Atayant Casual Kurti(White)', 'L,M,Xl', 300, NULL, 'k2.jpg', NULL),
	(2, 'Kurtas & Kurtis', 'Shakumbhari Printed Women anarkali Kurta', 'L,M,Xl', 500, NULL, 'k3.jpg', NULL),
	(3, 'Shirts & Tops', 'Clo Clu Women Shrug', 'L,M,Xl', 498, NULL, 't6.jpg', NULL),
	(4, 'Shirts & Tops', 'Veakupia Casual Grey Top', 'L,,M,Xl,Xll', 499, NULL, 't3.jpg', NULL),
	(5, 'Leggings & Jeggings', 'DEVIS High Waisr Jegging', '28,30,32', 850, NULL, 'j4.jpg', NULL),
	(6, 'Footwear', 'Sam Stefy Women Black Heels', '6,7,8', 500, NULL, 'f2.jpg', NULL),
	(7, 'Shirts & Tops', 'Miss Chase Casual Full Sleeve Grey Top', 'L,,M,Xl,Xll', 399, NULL, 't2.jpg', NULL),
	(8, 'Leggings & Jeggings', 'GUGG Mid Waist Jegging', '28,30,32', 699, NULL, 'j3.jpg', NULL),
	(9, 'Footwear', 'Bellies(Black)', '6,7,8', 699, NULL, 'f3.jpg', NULL),
	(10, 'Footwear', 'The Fashin Women Burgundy Heels', '6,7,8', 499, NULL, 'f1.jpg', NULL),
	(11, 'Kurtas & Kurtis', 'Drapes Crepe Printed Suit', 'L,M,Xl', 413, NULL, 'k5.jpg', NULL),
	(12, 'Footwear', 'Catwalk Casual Women Heels', '6,7,8', 999, NULL, 'f4.jpg', NULL),
	(13, 'Kurtas & Kurtis', 'Chanderi Embroidered Suit Dupatta Material', 'L,M,Xl', 654, NULL, 'k4.jpg', NULL),
	(14, 'Shirts & Tops', 'Global Desi Woen Tunic', 'L,M,Xl', 999, NULL, 't1.jpg', NULL),
	(15, 'Trousers', 'Stop Look Regular Multicolor Trousers', '28,30', 449, NULL, 't4.jpg', NULL),
	(16, 'Leggings & Jeggings', 'DEVIS High Waisr Jegging(Blue)', '28,30,32', 850, NULL, 'j1.jpg', NULL),
	(17, 'Leggings & Jeggings', 'CREEZ Printed Women Mountain Valley Jeggings', '28,30,32', 799, NULL, 'j2.jpg', NULL),
	(18, 'Trousers', 'KANNAN Regular Fit Women Drak Blue,Black Trouser', '28,30,32', 639, NULL, 't5.jpg', NULL),
	(19, 'Kurtas & Kurtis', 'Blue dress', '28,30,32', 599, NULL, 'k1.jpg', NULL),
	(20, 'Kurtas & Kurtis', 'cinderlla Dress', 'MEDIUM SIZW', 1599, 'Made up ofCotton', 'c1.jpg', 44);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;


-- Dumping structure for table fashion.user
CREATE TABLE IF NOT EXISTS `user` (
  `Name` varchar(50) default NULL,
  `Password` varchar(50) default NULL,
  `Email` varchar(50) NOT NULL default '',
  `Contact` varchar(50) default NULL,
  `User_type` varchar(50) default NULL,
  PRIMARY KEY  (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table fashion.user: ~2 rows (approximately)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`Name`, `Password`, `Email`, `Contact`, `User_type`) VALUES
	('abhi', '123', 'abhi@gmail.com', '4234', 'User'),
	('kamini', '123', 'kd@gmail.com', '2353', 'admin');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
/*!40014 SET FOREIGN_KEY_CHECKS=1 */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
