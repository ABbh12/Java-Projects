package filters;

import java.io.IOException;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beam.Question;
import db.DAO;

public class QuestionFilter implements Filter {

	private List<Question> allQuestion;

	public void destroy() {
		allQuestion = null;
	}

	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws IOException, ServletException {

		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) resp;

		HttpSession session = request.getSession(false);

		if (session != null) {
			String subject = (String) session.getAttribute("subject");
			if (subject == null) {

				subject = req.getParameter("subject");
				
				session.setAttribute("subject", subject);
			
			}
			if (allQuestion == null) {
				allQuestion = DAO.getAllQuestion(subject);
			}
			int qid = Integer.parseInt(req.getParameter("qid"));

			if (qid < allQuestion.size()) {

				if (qid > 0) {

					Question question = allQuestion.get(qid - 1);

					String selectedAns = req.getParameter("rbAns");
					question.setSelectans(selectedAns);
				}
				Question ques = allQuestion.get(qid);

				req.setAttribute("ques", ques);

			

			} else if (qid == allQuestion.size()) 
			{

			Question question = allQuestion.get(qid - 1);

			String selectedAns = req.getParameter("rbAns");
			question.setSelectans(selectedAns);

			
				DAO.submitExam(allQuestion);

				response.sendRedirect("/OnlineExam/pages/user/Submit.jsp");
			}
			chain.doFilter(req, resp);
		} else {
			response.sendRedirect("/OnlineExam/pages/user/Home.jsp");
		}

	}

	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

}
