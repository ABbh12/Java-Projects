package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import beam.Question;
import beam.Subject;
import beam.User;

public class DAO {

	public static void studentregister(User stud) {
		Connection con = dbConnection.getConnection();

		String q = "insert into user values(?,?,?,?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, stud.getName());
			ps.setString(2, stud.getPass());
			ps.setString(3, stud.getEmail());
			ps.setString(4, stud.getContact());
			ps.setString(5, "User");
			ps.executeUpdate();
			ps.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static User authenticateUser(String email, String password) {
		Connection con = dbConnection.getConnection();
		String q = "select * from user where Email=? and Password=?";
		User user = null;
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, email);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				user = new User();
				user.setContact(rs.getString("Contact"));
				user.setName(rs.getString("Name"));
				user.setPass(rs.getString("Password"));
				user.setEmail(rs.getString("Email"));
				user.setUsertype(rs.getString("User_type"));

			}
			ps.close();
			con.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return user;
	}

	public static void addQuestion(Question ques) {

		Connection con = dbConnection.getConnection();

		String query = "insert into question_table (Subject,question,optionA,optionB,optionC,optionD,Answer) values(?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, ques.getType());
			ps.setString(2, ques.getQuestion());
			ps.setString(3, ques.getOptionA());
			ps.setString(4, ques.getOptionB());
			ps.setString(5, ques.getOptionC());
			ps.setString(6, ques.getOptionD());
			ps.setString(7, ques.getAnswer());
			ps.executeUpdate();
			ps.close();
			con.close();
		}

		catch (SQLException e) {

			e.printStackTrace();
		}
	}

	public static void addSubject(Subject subj) {
		Connection con = dbConnection.getConnection();
		String query = "insert into subject (subject) values(?)";
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, subj.getSubject());
			ps.executeUpdate();
			ps.close();
			con.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public static List<String> getAllSubject() {
		List<String> allSubjects = new ArrayList<String>();
		Connection con = dbConnection.getConnection();
		String query = " Select * from subject";
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				allSubjects.add(rs.getString("subject"));
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return allSubjects;

	}

	public static List<Question> getAllQuestion(String subject) {
		List<Question> allquestion = new ArrayList<Question>();
		Connection con = dbConnection.getConnection();
		String query = " Select * from question_table where Subject=?";
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, subject);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				Question ques = new Question();
				ques.setId(rs.getInt("Question_id"));
				ques.setType(rs.getString("Subject"));
				ques.setQuestion(rs.getString("question"));
				ques.setOptionA(rs.getString("optionA"));
				ques.setOptionB(rs.getString("optionB"));
				ques.setOptionC(rs.getString("optionC"));
				ques.setOptionD(rs.getString("optionD"));
				ques.setAnswer(rs.getString("Answer"));
				ques.setSelectans(rs.getString("selectans"));
				allquestion.add(ques);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return allquestion;
	}

	public static void submitExam(List<Question> allQuestion) {

		Connection con = dbConnection.getConnection();
		try {
			for (Question ques : allQuestion) {
				String query = "UPDATE question_table SET selectans=? WHERE Question_id=?";
				PreparedStatement ps = con.prepareStatement(query);
				ps.setString(1, ques.getSelectans());
				ps.setInt(2, ques.getId());
				ps.executeUpdate();

				ps.close();
			}
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
