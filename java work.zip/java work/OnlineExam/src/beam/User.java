package beam;

public class User {
	
	private String name;
	private String pass;
	private String email;
	private String contact;
	private String Usertype;
	public String getUsertype() {
		return Usertype;
	}
	public void setUsertype(String usertype) {
		this.Usertype = usertype;
	}
	public String getContact() {
		return contact;
	}
	public String getEmail() {
		return email;
	}
	public String getName() {
		return name;
	}
	public String getPass() {
		return pass;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
}
