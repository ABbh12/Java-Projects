package servlets;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beam.User;
import db.DAO;

public class StudentRegistrationServlet extends HttpServlet {
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String name=request.getParameter("txtName");
		String pass=request.getParameter("txtPass");
		String email=request.getParameter("txtEmail");
		String contact=request.getParameter("txtContact");
		
		User user=new User();
		user.setName(name);
		user.setPass(pass);
		user.setEmail(email);
		user.setContact(contact);
		
		DAO.studentregister(user);
		response.sendRedirect("/OnlineExam/pages/user/Home.jsp");
	}

}
