package servlets;

import java.io.IOException;
//import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.DAO;

import beam.Subject;

public class AddSubject extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String subject =request.getParameter("txtsubject");
		Subject subj=new Subject();
		subj.setSubject(subject);
		DAO.addSubject(subj);
		response.sendRedirect("/OnlineExam/pages/admin/Home.jsp");
		
	}

}
