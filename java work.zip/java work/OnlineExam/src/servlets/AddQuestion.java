package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.DAO;

import beam.Question;

public class AddQuestion extends HttpServlet {

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	String type=request.getParameter("type");
	String question=request.getParameter("Ques");
	String optionA=request.getParameter("optionA");
	String optionB=request.getParameter("optionB");
	String optionC=request.getParameter("optionC");
	String optionD=request.getParameter("optionD");
	String answer=request.getParameter("Answer");
	
	Question ques=new Question();
	ques.setType(type);
	ques.setQuestion(question);
	ques.setOptionA(optionA);
	ques.setOptionB(optionB);
	ques.setOptionC(optionC);
	ques.setOptionD(optionD);
	ques.setAnswer(answer);
	
	DAO.addQuestion(ques);
	response.sendRedirect("/OnlineExam/pages/admin/Home.jsp");
	}

}
