package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beam.User;

import db.DAO;

public class LoginServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user=new User();
	String Email=request.getParameter("txtEmail");
	String password=request.getParameter("txtPass");
         user=DAO.authenticateUser(Email, password);
	
	if(user!=null)
	{
		HttpSession session=request.getSession(true);
		session.setAttribute("user",user);
		if ("Admin".equalsIgnoreCase(user.getUsertype())) {
		response.sendRedirect("/OnlineExam/pages/admin/Home.jsp");
		} else {
			response.sendRedirect("/OnlineExam/pages/user/Home.jsp");
		}
	}
	else
	{
		response.sendRedirect("/OmlineExam/pages/Welcome.jsp?msg=invalid Email aur Password");
	}
	}
}


