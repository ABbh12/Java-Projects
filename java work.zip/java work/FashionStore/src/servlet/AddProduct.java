package servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;

import db.DAO;

import beans.Product;

public class AddProduct extends HttpServlet {

	
	//private static final int MAX_MEM_SIZE1 = 0;
	//private static final long MAX_FILE_SIZE1 = 0;

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	
		// Check that we have a file upload request
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);

		if (!isMultipart) {
			return;
		}

		DiskFileItemFactory factory = new DiskFileItemFactory();

		// maximum size that will be stored in memory
		factory.setSizeThreshold(MAX_MEM_SIZE1);

		// Location to save data that is larger than maxMemSize.
		File tempDir = new File("c:\\temp");
		tempDir.mkdir();

		factory.setRepository(tempDir);

		// constructs path of the directory to save uploaded file
		String savePath = getServletContext().getInitParameter("UploadImage");

		// Create a new file upload handler
		ServletFileUpload upload = new ServletFileUpload(factory);
		// maximum file size to be uploaded.
		upload.setSizeMax(MAX_FILE_SIZE1);
		Map<String, String> map = new HashMap<String, String>();
		try {
			// Parse the request to get file items.
			List<FileItem> fileItems = upload.parseRequest(request);

			// Process the uploaded file items

			for (FileItem fileItem : fileItems) {

				if (fileItem.isFormField()) {

					map.put(fileItem.getFieldName(), fileItem.getString());

				} else {

					// Get the uploaded file parameters
					String filePathName = fileItem.getName();

					String fileName = FilenameUtils.getName(filePathName);

					File outputFile = new File(savePath + "\\" + fileName);

					fileItem.write(outputFile);

					map.put("txtImage", fileName);
				}

			}

		} catch (Exception ex) {
			System.out.println(ex);
		}
		String image = map.get("txtImage");
		String category=map.get("type");
		String name=map.get("txtName");
		String size=map.get("txtSize");
		float price=Float.parseFloat(map.get("txtPrice"));
		String descp=map.get("txtDescp");
		
	
		int quantity=Integer.parseInt(map.get("txtQuantity"));
		
		Product product=new Product();
		product.setCategory(category);
		product.setName(name);
		product.setSize(size);
		product.setPrice(price);
		product.setDescription(descp);
		product.setImage(image);
		product.setQuantity(quantity);
		
		DAO.addProduct(product);
		response.sendRedirect("/FashionStore/pages/admin/home.jsp");
	}
	private int MAX_FILE_SIZE1 = 5 * 1024 * 1024;// 5 MB
	private int MAX_MEM_SIZE1 = 4 * 1024;// 4 KB

}
