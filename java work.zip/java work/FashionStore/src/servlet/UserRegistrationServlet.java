package servlet;

import java.io.IOException;
import beans.User;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.DAO;

public class UserRegistrationServlet extends HttpServlet {
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String name=request.getParameter("txtName");
		String pass=request.getParameter("txtPassword");
		String email=request.getParameter("txtEmail");
		String contact=request.getParameter("txtContact");
		
		User user=new User();
		user.setName(name);
		user.setPassword(pass);
		user.setEmail(email);
		user.setContact(contact);
		
		DAO.userregister(user);
		response.sendRedirect("/FashionStore/pages/Welcome.jsp");
	}

}
