package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.Product;
import db.DAO;

public class KartServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		HttpSession session = req.getSession(false);
		int id = Integer.parseInt(req.getParameter("id"));

		if (session != null) {

			ArrayList<Product> kart = (ArrayList<Product>) session
					.getAttribute("kart");

			List<Product> list = DAO.getProduct(id);

			Product product = list.get(0);
			kart.add(product);
			req.setAttribute("kart", kart);
		//	resp.sendRedirect("/FashionStore/pages/user/AddKart.jsp");
		}
		resp.sendRedirect("/FashionStore/pages/user/AddKart.jsp");
	}

}
