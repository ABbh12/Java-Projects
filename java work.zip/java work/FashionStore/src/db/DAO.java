package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beans.Category;
import beans.Kart;
import beans.Product;
import beans.User;

public class DAO {
	public static User authenticateUser(String email, String password) {
		Connection con = dbConnection.getConnection();
		User user = null;
		String selectSQL = "SELECT * FROM user where Email=? and Password=?";

		try {

			PreparedStatement ps = con.prepareStatement(selectSQL);

			ps.setString(1, email);

			ps.setString(2, password);

			java.sql.ResultSet rs = ps.executeQuery();
			if (rs.next())

			{

				user = new User();
				user.setName(rs.getString("Name"));
				user.setEmail(rs.getString("Email"));
				user.setPassword(rs.getString("Password"));
				user.setContact(rs.getString("Contact"));
				user.setUserType(rs.getString("User_type"));

			}
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return user;

	}

	public static void userregister(User user) {
	
		Connection con = dbConnection.getConnection();

		String q = "insert into user values(?,?,?,?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, user.getName());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getEmail());
			ps.setString(4, user.getContact());
			ps.setString(5, "User");
			ps.executeUpdate();
			ps.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		
	}

	public static void addCategory(Category catg) {
		
		Connection con = dbConnection.getConnection();

		String q = "insert into category (category_name) values(?)";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1,catg.getCategroy());
			ps.executeUpdate();
			ps.close();
			con.close();
		} 
		catch (Exception e) {

			e.printStackTrace();
		}
	}

	public static List<String> getAllCategory() {
		
		Connection con = dbConnection.getConnection();
		List<String> allCategory=new ArrayList<String>();
		String q = "select category_name from category";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				allCategory.add(rs.getString("category_name"));
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return allCategory;
	}

	public static List<Product> getAllProduct() {
		
		Connection con = dbConnection.getConnection();
		List<Product> allproduct=new ArrayList<Product>();
		String q = "select * from product";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Product prod=new Product();
				
				prod.setId(rs.getInt("id"));
				prod.setCategory(rs.getString("category"));
				prod.setName(rs.getString("name"));
				prod.setSize(rs.getString("size"));
				prod.setPrice(rs.getFloat("price"));
				prod.setDescription(rs.getString("description"));
				prod.setImage(rs.getString("image"));
				prod.setQuantity(rs.getInt("quantity"));
				allproduct.add(prod);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return allproduct;
	}

	public static  List<Product> getProduct(int id) {
		
		Connection con = dbConnection.getConnection();
		Product prod=new Product();

		List<Product> allproduct=new ArrayList<Product>();
		String q = "select * from product where id=?";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				
				
				prod.setId(rs.getInt("id"));
				prod.setCategory(rs.getString("category"));
				prod.setName(rs.getString("name"));
				prod.setSize(rs.getString("size"));
				prod.setPrice(rs.getFloat("price"));
				prod.setDescription(rs.getString("description"));
				prod.setImage(rs.getString("image"));
				prod.setQuantity(rs.getInt("quantity"));
				allproduct.add(prod);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return allproduct;
	}

	public static List<Product> getSelectCategory(String cid) {
		
		Connection con = dbConnection.getConnection();
		List<Product> allproduct=new ArrayList<Product>();
		
		String q = "select * from product where category=?";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, cid);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Product prod=new Product();
				
				prod.setId(rs.getInt("id"));
				prod.setCategory(rs.getString("category"));
				prod.setName(rs.getString("name"));
				prod.setSize(rs.getString("size"));
				prod.setPrice(rs.getFloat("price"));
				prod.setDescription(rs.getString("description"));
				prod.setImage(rs.getString("image"));
				prod.setQuantity(rs.getInt("quantity"));
				allproduct.add(prod);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return allproduct;
		
	}

	public static void addProduct(Product product) {
		
		Connection con = dbConnection.getConnection();
		String q=" INSERT INTO product (category,name,size,price,description,image,quantity) VALUES(?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1,product.getCategory());
			ps.setString(2,product.getName());
			ps.setString(3,product.getSize());
			ps.setFloat(4,product.getPrice());
			ps.setString(5,product.getDescription());
			ps.setString(6,product.getImage());
			ps.setInt(7,product.getQuantity());
			ps.executeUpdate();
			ps.close();
			con.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public static Product o(int id) {
		Connection con = dbConnection.getConnection();
		Product prod=new Product();


		String q = "select * from product where id=?";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				
				
				prod.setId(rs.getInt("id"));
				prod.setCategory(rs.getString("category"));
				prod.setName(rs.getString("name"));
				prod.setSize(rs.getString("size"));
				prod.setPrice(rs.getFloat("price"));
				prod.setDescription(rs.getString("description"));
				prod.setImage(rs.getString("image"));
				prod.setQuantity(rs.getInt("quantity"));

			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return prod;
		
	
		}
	}	
		
	

	
	


